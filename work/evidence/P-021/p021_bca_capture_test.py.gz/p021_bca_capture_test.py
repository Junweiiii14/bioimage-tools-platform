import json
from pathlib import Path
from PySide6.QtWidgets import QFileDialog
from tests.test_project_navigation_session import js,session_window
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'work/evidence/P-021'
def test_bca_result_capture(session_window,qtbot,monkeypatch):
 w=session_window
 record=next(x for x in json.loads((OUT/'desktop-runs.json').read_text(encoding='utf-8')) if x['projection']['project']['tool']=='bca')
 monkeypatch.setattr(QFileDialog,'getExistingDirectory',lambda *a,**k:record['workspace'])
 qtbot.waitUntil(lambda:js(w,qtbot,'!!window.workflowEditor?.snapshot().connected') is True)
 js(w,qtbot,"document.querySelector('[data-workflow-open]').click();document.querySelector('[data-wf-choose=open_project]').click();true")
 qtbot.waitUntil(lambda:bool(w.authoring.projection))
 qtbot.waitUntil(lambda:js(w,qtbot,'!workflowEditor.snapshot().pending') is True)
 js(w,qtbot,"document.querySelector('#wf-refresh-results').click();document.querySelector('[data-wf-view=results]').click();true")
 qtbot.waitUntil(lambda:bool(w.authoring.projection.outputs))
 for width,height in [(1440,940),(960,720)]:
  w.resize(width,height)
  qtbot.waitUntil(lambda:js(w,qtbot,'innerWidth')==width)
  for theme in ['forest','ember','iris','neutral']:
   js(w,qtbot,f"document.documentElement.dataset.theme='{theme}';document.documentElement.dataset.motion='reduced';true")
   qtbot.wait(800)
   assert w.grab().save(str(OUT/'screenshots'/f'bca-{theme}-{width}.png'))
 js(w,qtbot,"document.querySelector('[data-wf-view=graph]').click();true")
 qtbot.wait(800)
 assert w.grab().save(str(OUT/'screenshots'/'bca-graph-final.png'))
