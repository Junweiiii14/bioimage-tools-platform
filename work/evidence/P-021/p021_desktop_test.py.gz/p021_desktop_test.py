import json, time, subprocess, sys
from pathlib import Path
from PySide6.QtWidgets import QFileDialog
from tests.test_project_navigation_session import js, session_window
from tests.test_research_authoring import plate_at

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'work/evidence/P-021'
WORKER='C:/Users/70236/ResearchVault/Codex-Workbench/p015-research/worker-env/Scripts/python.exe'
MODEL='C:/Users/70236/ResearchVault/Codex-Workbench/p014-research/models/2D_versatile_fluo'
INPUTS=Path('C:/Users/70236/ResearchVault/Codex-Workbench/p014-research/evaluation-input')

def test_desktop_research(session_window,qtbot,monkeypatch,tmp_path):
    w=session_window
    w.settings.setValue('nuclei_worker_v1',WORKER)
    w.settings.setValue('nuclei_model_v1',MODEL)
    chosen=[]
    parent=str(tmp_path)
    template=tmp_path/'nuclei-template.json'
    monkeypatch.setattr(QFileDialog,'getOpenFileName',lambda *a,**k:(chosen.pop(0),''))
    monkeypatch.setattr(QFileDialog,'getExistingDirectory',lambda *a,**k:parent)
    monkeypatch.setattr(QFileDialog,'getSaveFileName',lambda *a,**k:(str(template),''))
    qtbot.waitUntil(lambda:js(w,qtbot,'!!window.workflowEditor?.snapshot().connected') is True)
    js(w,qtbot,"document.querySelector('[data-workflow-open]').click();true")
    records=[]
    (OUT/'screenshots').mkdir(exist_ok=True)
    def click(selector):
        js(w,qtbot,f'document.querySelector({json.dumps(selector)}).click();true')
    def idle():
        qtbot.waitUntil(lambda:js(w,qtbot,'!workflowEditor.snapshot().pending') is True,timeout=20000)
        assert js(w,qtbot,"document.querySelector('#wf-status').dataset.error") != 'true', js(w,qtbot,"document.querySelector('#wf-status').textContent")
    def run(tool):
        start=time.perf_counter()
        click('#wf-run')
        qtbot.waitUntil(lambda:bool(w.authoring.projection and w.authoring.projection.outputs),timeout=100000)
        qtbot.waitUntil(lambda:not w.authoring.busy,timeout=20000)
        projection=w.authoring.projection
        assert projection.batch.state=='completed'
        workspace=js(w,qtbot,"document.querySelector('#wf-workspace-path').textContent")
        records.append({'tool':tool,'seconds':time.perf_counter()-start,'workspace':workspace,'projection':projection.model_dump(mode='json')})
        return workspace,projection.project.document_id
    def captures(tool):
        click('[data-wf-view=results]')
        for width,height in [(1440,940),(960,720)]:
            w.resize(width,height)
            qtbot.waitUntil(lambda:js(w,qtbot,'innerWidth')==width)
            for theme in ['forest','ember','iris','neutral']:
                js(w,qtbot,f"document.documentElement.dataset.theme='{theme}';document.documentElement.dataset.motion='reduced';true")
                qtbot.wait(800)
                assert w.grab().save(str(OUT/'screenshots'/f'{tool}-{theme}-{width}.png'))
    chosen[:]=[str(INPUTS/'Ganglioneuroblastoma_10.tif')]
    click('[data-wf-choose=new_nuclei]');idle()
    assert not w.authoring.projection.issues
    click('[data-wf-choose=export_template]');idle()
    first,doc=run('nuclei-first')
    assert '46' in next(o.text for o in w.authoring.projection.outputs if o.port=='labels')
    captures('nuclei')
    chosen[:]=[str(template),str(INPUTS/'Neuroblastoma_13.tif')]
    click('[data-wf-choose=new_template]');idle()
    second,_=run('nuclei-second')
    # Cold result verification does not need a model runtime.
    code='import sys,json; from platform_runtime.api import Workspace; from bioimage_app.workflow_authoring_store import execute_authoring_store as r; s=Workspace.open(sys.argv[1]); p=r(s,json.dumps(dict(operation="results",document_id=sys.argv[2])).encode()); print(json.dumps([(o.port,o.text[:100]) for o in p.outputs])); s.close()'
    cold=subprocess.run([sys.executable,'-I','-c',code,first,doc],capture_output=True,text=True,check=True,timeout=30)
    records.append({'cold_nuclei':json.loads(cold.stdout)})
    chosen[:]=list(plate_at(tmp_path,'graph-plate'))
    click('[data-wf-choose=new_bca]');idle()
    run('bca')
    captures('bca')
    click('[data-wf-view=graph]')
    qtbot.wait(800)
    assert w.grab().save(str(OUT/'screenshots'/'bca-graph-final.png'))
    # Output identities and asset digests only; avoid large base64 previews in evidence.
    for record in records:
        if 'projection' in record:
            for output in record['projection']['outputs']: output['preview']='[display preview omitted]'
    (OUT/'desktop-runs.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
