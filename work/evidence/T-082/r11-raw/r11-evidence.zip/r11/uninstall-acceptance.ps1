﻿$ErrorActionPreference = 'Stop'
$evidence = $PSScriptRoot
$install = [IO.Path]::GetFullPath('C:/Users/70236/AppData/Local/Programs/BioImage WB 验收 t082-r11-a').TrimEnd('\')
$registry = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\BioImageTools.WB.Acceptance.t082-r11-a_is1'
$version = '0.14.0-Acceptance-t082-r11-a-ed830e1d3bab'
function SaveNew($Name, $Value) {
    $path = Join-Path $evidence $Name
    if (Test-Path -LiteralPath $path) { throw "Refuse overwrite: $path" }
    $Value | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath $path -Encoding UTF8
}
function HashFile([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
$report = Get-Content -LiteralPath (Join-Path $evidence 'ed830e1 安装态双诊断/acceptance.json') -Raw | ConvertFrom-Json
if ($report.phase -ne 'passed' -or $report.source_commit -ne 'ed830e1d3bab3d0c8c57f3766a898991e8a0f431') { throw 'Final diagnostics not passed' }
foreach ($process in $report.processes) { if ($process.exit_code -ne 0 -or $process.timed_out) { throw 'Diagnostic process failed' } }
$entry = Get-ItemProperty -LiteralPath $registry
if ($entry.DisplayVersion -ne $version -or [IO.Path]::GetFullPath($entry.InstallLocation).TrimEnd('\') -ne $install) { throw 'Unexpected installed identity' }
$uninstaller = Join-Path $install 'unins000.exe'
if ($entry.UninstallString -ne ('"' + $uninstaller + '"')) { throw 'Unexpected registered uninstaller' }
if (-not (Test-Path -LiteralPath $uninstaller -PathType Leaf)) { throw 'Missing registered uninstaller' }
if ((Get-Item -LiteralPath $install).Attributes -band [IO.FileAttributes]::ReparsePoint) { throw 'Install root is reparse point' }
$baseline = Get-Content -LiteralPath (Join-Path $evidence 'user-data-before-upgrade.json') -Raw | ConvertFrom-Json
$marker = (Get-ItemProperty -LiteralPath $baseline.settings_key).($baseline.settings_name)
if ($marker -ne $baseline.settings_value) { throw 'Settings marker changed before uninstall' }
$preserved = @()
foreach ($file in $baseline.files) {
    $path = Join-Path $baseline.fixtures $file.relative
    if ((HashFile $path) -ne $file.sha256 -or (Get-Item -LiteralPath $path).Length -ne $file.bytes) { throw "Original fixture changed: $path" }
    $preserved += [ordered]@{path=$path;sha256=$file.sha256;bytes=$file.bytes;kind='original-fixture'}
}
$inside = Join-Path $install '用户保留 合成验收'
if (-not ([IO.Path]::GetFullPath($inside).StartsWith($install + '\', [StringComparison]::OrdinalIgnoreCase))) { throw 'Probe escapes install root' }
if (Test-Path -LiteralPath $inside) { throw 'Probe destination exists' }
$null = New-Item -Path $inside -ItemType Directory
foreach ($file in $baseline.files) {
    $destination = [IO.Path]::GetFullPath((Join-Path $inside $file.relative))
    if (-not $destination.StartsWith($inside + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Fixture path escapes probe root' }
    $null = New-Item -Path ([IO.Path]::GetDirectoryName($destination)) -ItemType Directory -Force
    Copy-Item -LiteralPath (Join-Path $baseline.fixtures $file.relative) -Destination $destination
    if ((HashFile $destination) -ne $file.sha256) { throw 'Probe copy mismatch' }
    $preserved += [ordered]@{path=$destination;sha256=$file.sha256;bytes=$file.bytes;kind='inside-install-user-probe'}
}
foreach ($name in @('ed830e1 安装态历史项目', 'ed830e1 安装态双诊断')) {
    foreach ($file in (Get-ChildItem -LiteralPath (Join-Path $evidence $name) -File -Recurse)) {
        $preserved += [ordered]@{path=$file.FullName;sha256=(HashFile $file.FullName);bytes=$file.Length;kind='completed-validation-output'}
    }
}
SaveNew 'uninstall-preservation-before.json' ([ordered]@{schema=1;source_commit=$report.source_commit;files=$preserved;settings_key=$baseline.settings_key;settings_name=$baseline.settings_name;settings_value=$marker;inside_probe_created_after_strict_validation=$true;time=(Get-Date -Format o)})
& (Join-Path $evidence 'snapshot-laboratory.ps1') -OutputFile (Join-Path $evidence 'laboratory-after-diagnostics.json')
$labHash = 'b4e2b65b20c6380a4b6f32fdb541bf4c347b4cde5e241500581ee69e6ef17fc3'
if ((HashFile (Join-Path $evidence 'laboratory-after-diagnostics.json')) -ne $labHash) { throw 'Laboratory changed before uninstall' }
$arguments = @('/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', ('/LOG="' + (Join-Path $evidence 'uninstall-ed830e1.log') + '"'))
$started = Get-Date -Format o
$process = Start-Process -FilePath $uninstaller -ArgumentList $arguments -WindowStyle Hidden -PassThru
$null = $process.Handle
SaveNew 'uninstall-start.json' ([ordered]@{source_commit=$report.source_commit;install_root=$install;registry=$registry;version=$version;executable=$uninstaller;arguments=$arguments;pid=$process.Id;started=$started})
$ended = $process.WaitForExit(180000)
$exitCode = if ($ended) { $process.ExitCode } else { $null }
SaveNew 'uninstall-exit.json' ([ordered]@{pid=$process.Id;exit_code=$exitCode;timed_out=(-not $ended);ended=(Get-Date -Format o)})
if (-not $ended -or $null -eq $exitCode -or $exitCode -ne 0) { throw 'Uninstaller failed or timed out; no cleanup attempted' }
$failures = @()
$checks = @()
foreach ($file in $preserved) {
    $exists = Test-Path -LiteralPath $file.path -PathType Leaf
    $same = $exists -and (HashFile $file.path) -eq $file.sha256 -and (Get-Item -LiteralPath $file.path).Length -eq $file.bytes
    $checks += [ordered]@{path=$file.path;kind=$file.kind;preserved=$same}
    if (-not $same) { $failures += $file.path }
}
$shortcuts = Get-Content -LiteralPath (Join-Path $evidence 'acceptance-shortcuts-after-upgrade.json') -Raw | ConvertFrom-Json
$shortcutChecks = @($shortcuts | ForEach-Object { [ordered]@{path=$_.path;removed=(-not (Test-Path -LiteralPath $_.path))} })
$launcherRemoved = -not (Test-Path -LiteralPath (Join-Path $install 'BioImageWB-Acceptance.exe'))
$pythonRemoved = -not (Test-Path -LiteralPath (Join-Path $install 'runtime/python.exe'))
$registryRemoved = -not (Test-Path -LiteralPath $registry)
$settingsSame = (Get-ItemProperty -LiteralPath $baseline.settings_key).($baseline.settings_name) -eq $marker
& (Join-Path $evidence 'snapshot-laboratory.ps1') -OutputFile (Join-Path $evidence 'laboratory-after-uninstall.json')
$labSame = (HashFile (Join-Path $evidence 'laboratory-after-uninstall.json')) -eq $labHash
$residue = @(Get-ChildItem -LiteralPath $install -File -Recurse | ForEach-Object { $_.FullName.Substring($install.Length + 1) })
$passed = $failures.Count -eq 0 -and @($shortcutChecks | Where-Object { -not $_.removed }).Count -eq 0 -and $launcherRemoved -and $pythonRemoved -and $registryRemoved -and $settingsSame -and $labSame
SaveNew 'uninstall-preservation-after.json' ([ordered]@{schema=1;phase=$(if ($passed) {'passed'} else {'failed'});source_commit=$report.source_commit;installer_sha256=$report.verified.installer_sha256;files=$checks;failures=$failures;shortcuts=$shortcutChecks;registry_removed=$registryRemoved;launcher_removed=$launcherRemoved;runtime_python_removed=$pythonRemoved;settings_marker_preserved=$settingsSame;laboratory_unchanged=$labSame;laboratory_sha256=$labHash;remaining_install_files=$residue;manual_cleanup_performed=$false;ended=(Get-Date -Format o)})
if (-not $passed) { throw 'Uninstall preservation checks failed; evidence retained' }
Write-Output ([ordered]@{phase='passed';preserved_files=$checks.Count;shortcuts_removed=$shortcutChecks.Count;remaining_files=$residue.Count;settings_preserved=$settingsSame;laboratory_unchanged=$labSame;exit_code=$exitCode} | ConvertTo-Json -Compress)
