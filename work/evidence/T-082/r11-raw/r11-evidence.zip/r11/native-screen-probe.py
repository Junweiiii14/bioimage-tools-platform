"""Read installed Qt's native screen metrics; this is not a physical interaction test."""

import json
import os
import sys

import PySide6
from PySide6.QtGui import QGuiApplication

if not sys.flags.isolated or not sys.dont_write_bytecode:
    raise RuntimeError("Use the verified installed Python with -I -B")
app = QGuiApplication([])
if app.platformName() != "windows":
    raise RuntimeError("Native Windows platform required for this screen observation")
print(json.dumps({
    "scope": "installed Qt native Windows screen metrics; no visible product interaction",
    "python": sys.executable,
    "qt_package": PySide6.__file__,
    "qt_version": PySide6.__version__,
    "platform": app.platformName(),
    "scale_environment": {
        key: os.environ.get(key)
        for key in ("QT_SCALE_FACTOR", "QT_SCREEN_SCALE_FACTORS", "QT_FONT_DPI",
                    "QT_ENABLE_HIGHDPI_SCALING", "QT_AUTO_SCREEN_SCALE_FACTOR")
    },
    "screens": [{
        "name": screen.name(),
        "primary": screen is app.primaryScreen(),
        "device_pixel_ratio": screen.devicePixelRatio(),
        "logical_dpi": screen.logicalDotsPerInch(),
        "physical_dpi": screen.physicalDotsPerInch(),
        "logical_geometry": [screen.geometry().x(), screen.geometry().y(),
                             screen.geometry().width(), screen.geometry().height()],
    } for screen in app.screens()],
}, ensure_ascii=False, indent=2))
app.quit()
