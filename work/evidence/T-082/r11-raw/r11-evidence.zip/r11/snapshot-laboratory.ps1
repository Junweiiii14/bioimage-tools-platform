﻿param([Parameter(Mandatory=$true)][string]$OutputFile)
$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $OutputFile) { throw 'Snapshot must not overwrite an existing report' }
function TextHash([string]$Text) {
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose() }
}
function RegistrySnapshot([string]$RegistryPath) {
    if (-not (Test-Path -LiteralPath $RegistryPath)) { return [ordered]@{exists=$false} }
    $entries = @()
    $keys = @((Get-Item -LiteralPath $RegistryPath)) + @(Get-ChildItem -LiteralPath $RegistryPath -Recurse)
    foreach ($key in ($keys | Sort-Object Name)) {
        foreach ($name in ($key.GetValueNames() | Sort-Object)) {
            $value = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            $entries += [ordered]@{key=$key.Name;name=$name;kind=$key.GetValueKind($name).ToString();value=$value}
        }
    }
    return [ordered]@{exists=$true;values=$entries.Count;sha256=(TextHash ($entries | ConvertTo-Json -Depth 10 -Compress))}
}
$taskUninstall = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\BioImageTools.WB.Laboratory_is1'
$taskFiles = @()
$taskShortcutPaths = @()
$taskDesktop = [Environment]::GetFolderPath('DesktopDirectory')
$taskPrograms = [Environment]::GetFolderPath('Programs')
$taskDesktopShortcut = Join-Path $taskDesktop 'BioImage WB 实验室版.lnk'
if (Test-Path -LiteralPath $taskDesktopShortcut) { $taskShortcutPaths += $taskDesktopShortcut }
$taskMenu = Join-Path $taskPrograms 'BioImage WB 实验室版'
if (Test-Path -LiteralPath $taskMenu) { $taskShortcutPaths += @(Get-ChildItem -LiteralPath $taskMenu -File -Recurse | Select-Object -ExpandProperty FullName) }
$taskShell = New-Object -ComObject WScript.Shell
foreach ($path in ($taskShortcutPaths | Sort-Object)) {
    $entry = [ordered]@{path=$path;sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()}
    if ([IO.Path]::GetExtension($path) -eq '.lnk') {
        $shortcut = $taskShell.CreateShortcut($path)
        $entry.target=$shortcut.TargetPath
        $entry.arguments=$shortcut.Arguments
        $entry.working_directory=$shortcut.WorkingDirectory
    }
    $taskFiles += $entry
}
$taskInstalledFiles = @()
if (Test-Path -LiteralPath $taskUninstall) {
    $taskLocation = (Get-ItemProperty -LiteralPath $taskUninstall).InstallLocation
    foreach ($name in @('BioImageWB.exe', 'build-manifest.json', 'payload-files.json')) {
        $path = Join-Path $taskLocation $name
        $taskInstalledFiles += [ordered]@{name=$name;exists=(Test-Path -LiteralPath $path);sha256=$(if (Test-Path -LiteralPath $path) {(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()} else {$null})}
    }
}
$taskSnapshot = [ordered]@{
    schema=1
    uninstall=(RegistrySnapshot $taskUninstall)
    settings=(RegistrySnapshot 'HKCU:\Software\BioImageTools\Laboratory')
    shortcuts=$taskFiles
    installed_identity_files=$taskInstalledFiles
}
$taskSnapshot | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $OutputFile -Encoding UTF8
Write-Output ([ordered]@{report=$OutputFile;sha256=(Get-FileHash -LiteralPath $OutputFile -Algorithm SHA256).Hash.ToLowerInvariant()} | ConvertTo-Json -Compress)
