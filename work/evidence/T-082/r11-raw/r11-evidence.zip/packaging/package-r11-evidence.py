"""Package explicitly selected text evidence without touching products or installers."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
LOCAL = ROOT / ".local/T082/r11"
DEST = ROOT / "work/evidence/T-082/r11-raw"
FINAL = Path("C:/Users/70236/.codex/artifacts/T082-ed830e1/.local/releases/runtime-ed830e1d3bab-acceptance-t082-r11-a")
SUFFIXES = {".json", ".txt", ".log", ".stdout", ".stderr", ".ps1", ".py"}
sources: dict[str, Path] = {}


def add(member: str, path: Path) -> None:
    assert not member.startswith("/") and ".." not in Path(member).parts
    assert member not in sources, member
    assert path.is_file() and not path.is_symlink(), path
    assert path.suffix.lower() in SUFFIXES, path
    sources[member] = path.resolve()


for path in sorted(LOCAL.iterdir()):
    if path.is_file() and path.suffix.lower() in SUFFIXES:
        add("r11/" + path.name, path)

report_directories = [
    "升级起点候选 核验", "升级前安装内容 核验", "最终候选 核验-ps51",
    "ed830e1 候选核验-ps51", "ed830e1 候选核验-ps7",
    "ed830e1 持久候选核验-ps51", "ed830e1 持久候选核验-ps7",
    "ed830e1 升级后严格核验", "ed830e1 安装态双诊断",
]
requests = {}
for name in report_directories:
    for path in sorted((LOCAL / name).iterdir()):
        assert path.is_file(), path
        add("r11/" + name + "/" + path.name, path)
    report = json.loads((LOCAL / name / "acceptance.json").read_text(encoding="utf-8-sig"))
    if report.get("request"):
        request = Path(report["request"]["path"])
        requests[request.name] = request
        assert hashlib.sha256(request.read_bytes()).hexdigest() == report["request"]["sha256"]
for name, request in sorted(requests.items()):
    add("requests/" + name, request)

for relative in [
    "ed830e1 安装态历史项目/legacy-verification.json",
    "最终历史样例 d66655b/fixtures.json",
]:
    add("r11/" + relative, LOCAL / relative)

for commit in [
    "44ee78c36a0edb5d6cd9bd0798bbca3e25edd4da",
    "d66655b0cfd241c07f3b8647e08b1b3ef567e2d3",
    "ed830e1d3bab3d0c8c57f3766a898991e8a0f431",
]:
    for ending in [".txt", "-exit.json"]:
        path = ROOT / ".local/T082" / ("final-check-" + commit + ending)
        add("gates/" + path.name, path)

builds = {
    "ed830e1-persistent-final": FINAL,
    "d66655b-deep-failed": ROOT / ".local/releases/runtime-d66655b0cfd2-acceptance-t082-r11-a",
}
for label, record in [
    ("d66655b-temp", "final-artifact.json"),
    ("244c5da-temp-upgrade-base", "upgrade-base-artifact.json"),
    ("ed830e1-temp", "ed830e1-artifact.json"),
]:
    builds[label] = Path(json.loads((LOCAL / record).read_text(encoding="utf-8-sig"))["candidate"])
for label, directory in builds.items():
    for path in sorted(directory.iterdir()):
        if path.is_file() and path.suffix.lower() in {".json", ".txt", ".log"}:
            add("builds/" + label + "/" + path.name, path)
    for name in ["build-manifest.json", "payload-files.json"]:
        add("builds/" + label + "/app/" + name, directory / "app" / name)

add("packaging/package-r11-evidence.py", Path(__file__))

secret_patterns = {
    "private-key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "github-token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})\b"),
    "openai-style-key": re.compile(r"\bsk-(?:proj-)?[A-Za-z0-9_-]{40,}\b"),
    "authorization-bearer": re.compile(r"(?i)authorization\s*[:=]\s*['\"]?bearer\s+[A-Za-z0-9._-]{16,}"),
    "url-user-password": re.compile(r"https?://[^\s/@:]+:[^\s/@]+@"),
}
entries = []
data_by_member = {}
decodings = Counter()
for member, path in sorted(sources.items()):
    data = path.read_bytes()
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        text = data.decode("utf-16")
        encoding = "utf-16-bom"
    else:
        text = data.decode("utf-8-sig")
        encoding = "utf-8"
    assert "\x00" not in text, (member, "non-text")
    for label, pattern in secret_patterns.items():
        assert not pattern.search(text), (member, "potential-secret", label)
    decodings[encoding] += 1
    data_by_member[member] = data
    entries.append({
        "member": member, "source": path.as_posix(), "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(), "text_decoding_checked": encoding,
    })

DEST.mkdir(parents=True, exist_ok=False)
archive = DEST / "r11-evidence.zip"
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as package:
    for member, data in sorted(data_by_member.items()):
        info = zipfile.ZipInfo(member, date_time=(2026, 10, 28, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        package.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
    assert len(package.namelist()) == len(entries)
    for entry in entries:
        actual = package.read(entry["member"])
        assert len(actual) == entry["bytes"]
        assert hashlib.sha256(actual).hexdigest() == entry["sha256"]
        assert actual == Path(entry["source"]).read_bytes()

manifest = {
    "schema": 1, "source_commit": "ed830e1d3bab3d0c8c57f3766a898991e8a0f431",
    "archive": archive.name, "archive_bytes": archive.stat().st_size,
    "archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "members": len(entries), "uncompressed_bytes": sum(entry["bytes"] for entry in entries),
    "selection": "Explicit direct text files, allowlisted report directories, referenced request JSON, frozen gate logs, build text metadata; no recursive source/asset collection",
    "excluded": ["installers", "executables and libraries", "models", "images", "source-code.zip", "source checkouts", "legacy generated archives and binary render outputs"],
    "secret_scan": {"patterns": list(secret_patterns), "findings": 0, "decodings": dict(decodings), "limitation": "Pattern scan plus scoped synthetic-source selection, not a general proof of absence of all possible secrets"},
    "verification": "Every ZIP member reread; bytes/SHA256 and source bytes checked; ZIP CRC verified",
    "files": entries,
}
(DEST / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({key: manifest[key] for key in ["members", "uncompressed_bytes", "archive_bytes", "archive_sha256"]}))
